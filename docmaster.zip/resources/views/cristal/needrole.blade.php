 

            <div id="pricing" class="section pricing-section" >
                <div class="container">
                    <div class="section-header">
                        <h2 class="section-title wow fadeIn" data-wow-duration="1000ms" data-wow-delay="0.3s">Népszerű <span>Csomagjaink</span></h2>
                        <hr class="lines wow zoomIn" data-wow-delay="0.3s">
                        <p class="section-subtitle wow fadeIn" data-wow-duration="1000ms" data-wow-delay="0.3s">A letöltéshez előfizetés szükséges. <br>Kérjük válasszon  acsomsgjaink közül.</p>
                    </div>

                    @include('cristal.pricing')  

                </div>
            </div>
       


