<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\Constraint\IsFalse;

class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
   public function testExampleTest()
    {
        $this->assertEquals(1,1); 
     //   $this->assertTrue(true);
    }
 
}
