<!--
    <div class="form-group <?php echo e($errors->has('daytype_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('role_id', 'Jogosultság', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
      
        <?php echo Form::select('role_id', $data['roles'], 6, ['class' => 'form-control', 'required' => 'required']); ?>

        
         <?php echo $errors->first('role_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('role_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('role_id', 'Role Id', ['class' => 'control-label']); ?>

    <?php echo Form::number('role_id', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('role_id', '<p class="help-block">:message</p>'); ?>

</div> 
-->
<div class="form-group<?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('name', 'Név', ['class' => 'control-label']); ?>

    <?php echo Form::text('name', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('note') ? 'has-error' : ''); ?>">
    <?php echo Form::label('note', 'Megjegyzés', ['class' => 'control-label']); ?>

    <?php echo Form::text('note', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('note', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <?php echo Form::submit($formMode === 'edit' ? 'Update' : 'Create', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH H:\laravel\docmaster\resources\views/admin/category/form.blade.php ENDPATH**/ ?>