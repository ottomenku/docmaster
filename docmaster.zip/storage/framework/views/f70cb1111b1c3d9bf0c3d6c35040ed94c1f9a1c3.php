<?php $__env->startSection('content'); ?>
    <!-- Blog Section -->
    <section id="blog" class="section">
        <!-- Container Starts -->
<?php
$items=$data['list'] ?? [];
?>
   <div class="container">
            <div class="section-header" style="background-color:white;">
                <h2 class="section-title wow fadeIn" data-wow-duration="1000ms" data-wow-delay="0.3s"><span><?php echo e($data['catname']); ?></span></h2>
           </div>
            <div class="row">
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 blog-item" >
                    <!-- Blog Item Starts -->
                    <div class="blog-item-wrapper wow fadeInUp" data-wow-delay="0.3s">
                        <div class="blog-item-img">
                            <a href="single-post.html">
                                <img src="img/blog/img1.jpg" alt="">
                            </a>
                        </div>
                        <div class="blog-item-text" style="padding:5px;overflow: hidden;">
                        <center><img src="/docprev/thumb/<?php echo e($item['prev']); ?>" height="200px" width="200px"> </center>
                            <h3> <?php echo e($item['name']); ?></h3> 
                            <p>
                                    <?php echo e(Str::limit($item['note'] , 100)); ?>

                            </p>

                        <a href="http://localhost:8000/download/<?php echo e($item['id']); ?>"" class="btn btn-common" style="color:white;"
                        data-remote="false" data-toggle="modal" data-target="#myModal"><i class="lnr lnr-download"></i> Letöltés</a>
                        </div>
                    </div> 
                </div>
                    <!-- Blog Item Wrapper Ends-->
            
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
            </div>
    </section>
    <!-- Default bootstrap modal example -->
    <div class="modal fade bd-example-modal-lg " id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
           
          </div>
          <div class="modal-body">
            ...
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('cristal.frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel\docmaster\resources\views/cristal/category.blade.php ENDPATH**/ ?>