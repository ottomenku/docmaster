  <div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
        <?php echo Form::label('category_id', 'Kategória', ['class' => 'col-md-4 control-label']); ?>

        <div class="col-md-6">
          
            <?php echo Form::select('category_id', $data['categories'], null, ['class' => 'form-control',]); ?>

            
             <?php echo $errors->first('category_id', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>

<div class="form-group<?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('name', 'Név', ['class' => 'control-label']); ?>

    <?php echo Form::text('name', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('originalname') ? 'has-error' : ''); ?>">
    <?php echo Form::label('originalname', 'Eredeti név', ['class' => 'control-label']); ?>

    <?php echo Form::text('originalname', null, ['class' => 'form-control','readonly']); ?>

    <?php echo $errors->first('originalname', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group<?php echo e($errors->has('note') ? 'has-error' : ''); ?>">
    <?php echo Form::label('note', 'Megjegyzés', ['class' => 'control-label']); ?>

    <?php echo Form::text('note', null, ('' == 'required') ? ['class' => 'form-control'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('note', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('thumb') ? 'has-error' : ''); ?>">
    <?php echo Form::label('thumb', 'Előnézet', ['class' => 'control-label']); ?>

    <?php echo Form::file('thumb', null, ('required' == 'required') ? ['class' => 'form-control','id' => 'thumb', ] : ['class' => 'form-control']); ?>

    <?php 
     $prew=$data['doc']->prev ?? $data['doc']->type.'.png' ?? 'file.png'  ;
//$src='/docprev/thumb/'.$prew;
$src=url(App\Http\Controllers\Admin\DocController::$docPrev_path_final);
    ?>
   
    <img id="prewimg" src="<?php echo e($src); ?>/thumb/<?php echo e($prew); ?>" alt="your image" width="200px"  height="200px"/>
    
    <?php echo $errors->first('thumb', '<p class="help-block">:message</p>'); ?>

</div>
<script>
function imgPrev(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      
      reader.onload = function(e) {
        $('#prewimg').attr('src', e.target.result);
      }
      
      reader.readAsDataURL(input.files[0]);
    }
  }
  
  $("#thumb").change(function() {
    imgPrev(this);
  });
</script>

<div class="form-group">
    <?php echo Form::submit($formMode === 'edit' ? 'Update' : 'Create', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH H:\laravel\docmaster\resources\views/admin/doc/form.blade.php ENDPATH**/ ?>