
start: <input type="text" name="start" id="datepicker" value="<?php echo e($data['start']); ?>" >
end: <input type="text"  name="end" id="datepicker2" value="<?php echo e($data['end']); ?>"><br/><br/>
<div class="form-group <?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
        <?php echo Form::label('user_id', 'Felhasználó', ['class' => 'col-md-4 control-label']); ?>

        <div class="col-md-6">
          
            <?php echo Form::select('user_id', $data['users'], null, ['class' => 'form-control',]); ?>

            
             <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
<div class="form-group<?php echo e($errors->has('note') ? 'has-error' : ''); ?>">
        <?php echo Form::label('note', 'Megjegyzés', ['class' => 'control-label']); ?>

        <?php echo Form::text('note', null, ('' == 'required') ? ['class' => 'form-control'] : ['class' => 'form-control']); ?>

        <?php echo $errors->first('note', '<p class="help-block">:message</p>'); ?>

    </div>

<div class="form-group">
    <?php echo Form::submit($formMode === 'edit' ? 'Update' : 'Create', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH H:\laravel\docmaster\resources\views/admin/roletimes/form.blade.php ENDPATH**/ ?>