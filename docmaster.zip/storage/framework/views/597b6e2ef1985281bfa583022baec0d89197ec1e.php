<?php             
    $menuT=[
    'superadmin'=>[
    ['/admin/pages' ,' Pages'],                                                                              
    ['/admin/generator' ,' Generátor'],
    ['/admin/permissions' ,'Permission'],
    ['admin/activitylogs' ,'Activitylogs'],
    ['/admin/settings' ,'Settings'],
    ['/admin/roles', 'jogok'],

    ],
    
    'admin'=>[  
   
    ['/admin/roletimes' , 'Userjogok'],
    ['/admin/users' ,  'Felhasználók'],
    ['/admin/category','Kategóriák'],
    ['/admin/doc', 'Dokumentumok'],
    ['/admin/upload-image', ' upload'],
    ['/admin/pays', ' befizetések'],
    ['/admin/customers', ' Vevő adatok'],
    ],
    
    ];
 ?> 

<div class="col-md-3">
<?php if(Auth::user()->hasRole('admin')): ?>  

    <div class="card">     
        <div class="card-header">
            Admin nenü
        </div>

        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['admin']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>
    </div>                 
<?php endif; ?>   

<?php if(Auth::user()->hasRole('superadmin')): ?> 

    <div class="card">
        <div class="card-header">
            Szuperadmin menü
        </div>

        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['superadmin']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
    
        </div>  
    </div>
        
        
<?php endif; ?> 
</div>
        
<?php /**PATH H:\laravel\docmaster\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>