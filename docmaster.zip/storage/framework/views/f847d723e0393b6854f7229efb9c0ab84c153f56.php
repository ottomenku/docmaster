
<div class="card-body">
        <?php echo Form::model($data, [
            'method' => 'POST',
            'url' => [route('pay')],
            'class' => 'form-horizontal',
            'id' => "billingdataform"
        ]); ?>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
                <H6> HIBA!!! </H6>
        </div>
         <?php endif; ?>
        <h6> Kártyatulajdonos neve: </h6>
        <div class="form-group<?php echo e($errors->has('cardname') ? 'has-error' : ''); ?>">
                <?php echo $errors->first('cardname', '<p class="alert alert-danger">:message</p>'); ?>

                <?php echo Form::label('cardname', 'Kártyán szereplő Név', ['class' => 'control-label']); ?>

                <?php echo Form::text('cardname', null,  ['class' => 'form-control', 'required' => 'required']); ?>

             
            </div>
            <h6> Számlázási adatok: </h6>

            <div class="form-group<?php echo e($errors->has('fullname') ? 'has-error' : ''); ?>">
                    <?php echo Form::label('fullname', 'Név, cégnév', ['class' => 'control-label']); ?>

                    <?php echo $errors->first('fullname', '<p class="alert alert-danger">:message</p>'); ?>

                    <?php echo Form::text('fullname', null,  ['class' => 'form-control', 'required' => 'required']); ?>

                 
                </div>  

            <div class="form-group<?php echo e($errors->has('city') ? 'has-error' : ''); ?>">
                
                    <?php echo Form::label('city', 'Város', ['class' => 'control-label']); ?>

                    <?php echo $errors->first('city', '<p class="alert alert-danger">:message</p>'); ?>

                    <?php echo Form::text('city', null,  ['class' => 'form-control', 'required' => 'required']); ?>

                    
                </div>  

                <div class="form-group<?php echo e($errors->has('zip') ? 'has-error' : ''); ?>">
                        <?php echo Form::label('zip', 'Irányítószám', ['class' => 'control-label']); ?>

                        <?php echo $errors->first('zip', '<p class="alert alert-danger">:message</p>'); ?>

                        <?php echo Form::text('zip', null,   ['class' => 'form-control', 'required' => 'required']); ?>

                     
                    </div> 
                <div class="form-group<?php echo e($errors->has('adress') ? 'has-error' : ''); ?>">
                        <?php echo Form::label('adress', 'Utca, házszám', ['class' => 'control-label']); ?>

                        <?php echo $errors->first('adress', '<p class="alert alert-danger">:message</p>'); ?>

                        <?php echo Form::text('adress', null,   ['class' => 'form-control', 'required' => 'required']); ?>

                      
                    </div>  
                    <div class="form-group<?php echo e($errors->has('tel') ? 'has-error' : ''); ?>">
                        <?php echo Form::label('tel', 'Telefon', ['class' => 'control-label']); ?>

                        <?php echo $errors->first('tel', '<p class="alert alert-danger">:message</p>'); ?>

                        <?php echo Form::text('tel', null,  ['class' => 'form-control']); ?>

                     
                    </div> 

    <div class="form-group<?php echo e($errors->has('adosz') ? 'has-error' : ''); ?>">
                        <?php echo Form::label('adosz', 'Adószám', ['class' => 'control-label']); ?>

                        <?php echo $errors->first('adosz', '<p class="alert alert-danger">:message</p>'); ?>

                        <?php echo Form::text('adosz', null,  ['class' => 'form-control']); ?>

                       
                    </div> 
                    
               <input type="hidden"  name="order_id" value"<?php echo e($data['order_id']); ?>">        
                    <div class="form-group">
                            <input id="saveBtn" onclick="datasend();" class="btn btn-primary" type="button" value="Tovább a fizetéshez">
                        </div>
    </form>
</div>
<?php /**PATH H:\laravel\docmaster\resources\views/cristal/billingdata.blade.php ENDPATH**/ ?>